<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="66.223" height="46.781" viewBox="0 0 66.223 46.781">
        <g id="Group_7" data-name="Group 7" transform="translate(0 0)">
            <g id="Group_1" data-name="Group 1" transform="translate(20.729)">
                <path id="Path_1" data-name="Path 1" d="M709.828,106.953q7.049,12.389,14.092,24.782c.808,1.426,1.534,2.9,2.48,4.7H719.24c-2.536-4.364-5.118-8.7-7.593-13.091-3.062-5.436-6.034-10.923-9.046-16.388Z" transform="translate(-702.602 -106.953)" fill="#489aab"/>
            </g>
            <g id="Group_2" data-name="Group 2" transform="translate(0 8.413)">
                <path id="Path_2" data-name="Path 2" d="M181.82,356.672c7.365-12.757,14.55-25.274,22.11-38.368L207.447,324c-6.228,10.832-12.441,21.485-18.875,32.675Z" transform="translate(-181.82 -318.304)" fill="#489aab"/>
            </g>
            <g id="Group_3" data-name="Group 3" transform="translate(25.462 32.22)">
                <path id="Path_3" data-name="Path 3" d="M862.268,916.435l-3.317,5.722H821.507l3.178-5.722Z" transform="translate(-821.507 -916.435)" fill="#489aab"/>
            </g>
            <g id="Group_4" data-name="Group 4" transform="translate(32.549 3.266)">
                <path id="Path_4" data-name="Path 4" d="M1021.993,215.187h-7.4l-15.027-26.193h7.361Z" transform="translate(-999.566 -188.994)" fill="#489aab"/>
            </g>
            <g id="Group_5" data-name="Group 5" transform="translate(10.42 17.235)">
                <path id="Path_5" data-name="Path 5" d="M460.437,539.952l3.441,5.874c-4.474,7.756-9.013,15.741-13.588,23.672H443.6C449.271,559.585,454.665,550.042,460.437,539.952Z" transform="translate(-443.599 -539.952)" fill="#489aab"/>
            </g>
            <g id="Group_6" data-name="Group 6" transform="translate(20.376 41.351)">
                <path id="Path_6" data-name="Path 6" d="M696.687,1145.815H726.4l-3.111,5.43H693.734Z" transform="translate(-693.734 -1145.815)" fill="#489aab"/>
            </g>
        </g>
    </svg>
</template>
